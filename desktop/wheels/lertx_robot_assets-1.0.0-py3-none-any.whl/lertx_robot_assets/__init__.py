"""Exact packaged SO-101 resources; no runtime acquisition or conversion."""
